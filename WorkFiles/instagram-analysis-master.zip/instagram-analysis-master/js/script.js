$(document).ready( function() { 
        $("#analysis").tablesorter(); 
    } 
); 
   

